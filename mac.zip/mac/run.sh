#!/bin/bash

./node run.js
